package com.bankoffairfield.customeraccountsmgmtapp.service.impl;

import com.bankoffairfield.customeraccountsmgmtapp.model.Account;
import com.bankoffairfield.customeraccountsmgmtapp.repository.AccountRepository;
import com.bankoffairfield.customeraccountsmgmtapp.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AccountServiceImpl implements AccountService {
    @Autowired
    private AccountRepository accountRepository;

    @Override
    public List<Account> getAccounts() {
        return accountRepository.findAll(Sort.by(Sort.Order.desc("balance")));
    }

    @Override
    public Account saveAccount(Account account) {
        return accountRepository.save(account);
    }
}
