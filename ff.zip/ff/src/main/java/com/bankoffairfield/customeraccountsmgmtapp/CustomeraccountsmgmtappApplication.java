package com.bankoffairfield.customeraccountsmgmtapp;

import com.bankoffairfield.customeraccountsmgmtapp.model.Account;
import com.bankoffairfield.customeraccountsmgmtapp.model.Customer;
import com.bankoffairfield.customeraccountsmgmtapp.service.AccountService;
import com.bankoffairfield.customeraccountsmgmtapp.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import java.time.LocalDate;

@SpringBootApplication

public class CustomeraccountsmgmtappApplication  {
@Autowired
    private AccountService accountService;
@Autowired
private CustomerService customerService;
    public static void main(String[] args) {
        SpringApplication.run(CustomeraccountsmgmtappApplication.class, args);
    }

//    @Override
//    public void run(String... args) throws Exception {
//        Account acc1= new Account( "000-61-0001","Checking",  LocalDate.of(2021,5,24),2000.0);
//        Account acc2 = new Account( "000-61-0002","Saving",  LocalDate.of(2019,6,12),1600.0);
//        Account acc3 = new Account( "000-61-0003","Saving",  LocalDate.of(2020,8,16),400.0);
//        Account acc4= new Account( "000-61-0004","Checking",  LocalDate.of(2021,7,19),10000.0);
//        Customer cus1 = new  Customer("C124", "Abe", "6411231234","Secs@gmail.com");
//        Customer cus2 = new  Customer("C126", "Jota", "7077647999","dJota@gmail.com");
//
//        Customer [] customers ={cus1,cus2};
//        for (Customer cus:customers) {
//            customerService.saveCustomer(cus);
//        }
//        acc1.setCustomer(cus1);
//        acc2.setCustomer(cus1);
//        acc3.setCustomer(cus2);
//        acc4.setCustomer(cus2);
//        Account[] accounts={acc1,acc2,acc3,acc4};
//        for (Account acc:accounts){
//            accountService.saveAccount(acc);
//        }
//    }
}
