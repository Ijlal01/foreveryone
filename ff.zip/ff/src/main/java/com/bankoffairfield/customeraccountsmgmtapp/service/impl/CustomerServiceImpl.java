package com.bankoffairfield.customeraccountsmgmtapp.service.impl;

import com.bankoffairfield.customeraccountsmgmtapp.model.Customer;
import com.bankoffairfield.customeraccountsmgmtapp.repository.CustomerRepository;
import com.bankoffairfield.customeraccountsmgmtapp.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService {
@Autowired
    private CustomerRepository customerRepository;

    @Override
    public List<Customer> getCustomers() {
        return customerRepository.findAll(Sort.by("name"));
    }

    @Override
    public Customer saveCustomer(Customer customer) {
        return customerRepository.save(customer);
    }

}
