package com.bankoffairfield.customeraccountsmgmtapp.controller;

import com.bankoffairfield.customeraccountsmgmtapp.model.Account;
import com.bankoffairfield.customeraccountsmgmtapp.model.Customer;
import com.bankoffairfield.customeraccountsmgmtapp.service.AccountService;
import com.bankoffairfield.customeraccountsmgmtapp.service.CustomerService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import javax.validation.Valid;
import java.util.List;

@Controller
@RequestMapping(value = {"/cadman/account"})
public class AccountController {
    private AccountService accountService;
    private CustomerService customerService;

    public AccountController(AccountService accountService, CustomerService customerService) {
        this.accountService = accountService;
        this.customerService = customerService;
    }
    @GetMapping(value = {"/list"})
    public ModelAndView listAccounts(){
        var modelAndView = new ModelAndView();
        List<Account> accounts = accountService.getAccounts();
        modelAndView.addObject("accounts",accounts);
        modelAndView.setViewName("account/list");
        return modelAndView;

    }

    @GetMapping(value = {"/newaccountform"})
    public String displayNewAccountForm(Model model) {
        model.addAttribute("account", new Account());
        model.addAttribute("customers", this.customerService.getCustomers());
        return "account/newaccountform";
    }

    @PostMapping(value = {"/newaccountform"})
    public String addNewAccount(@Valid
                             @ModelAttribute("account") Account account
            , BindingResult bindingResult,
                             Model model) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("errors", bindingResult.getAllErrors());
            List<Customer> customers = this.customerService.getCustomers();
            model.addAttribute("customers", customers);
            return "account/newaccountform";
        }
        account = accountService.saveAccount(account);
        return "redirect:/account/list";
    }
}
