package com.bankoffairfield.customeraccountsmgmtapp.service;

import com.bankoffairfield.customeraccountsmgmtapp.model.Account;
import org.springframework.stereotype.Service;


import java.util.List;
@Service
public interface AccountService {
    public abstract List<Account> getAccounts();
    public abstract Account saveAccount(Account account);
}
