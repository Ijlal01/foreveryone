package com.bankoffairfield.customeraccountsmgmtapp.service;

import com.bankoffairfield.customeraccountsmgmtapp.model.Customer;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public interface CustomerService {

    public abstract List<Customer> getCustomers();
    public abstract Customer saveCustomer(Customer customer);
}
