package com.bankoffairfield.customeraccountsmgmtapp.model;

import lombok.*;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.List;
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Table(name="customers")
public class Customer {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer customerId;
    @Column(nullable = false, unique = true)
    @NotNull(message = "Customer Number is required")
    @NotBlank(message = "Customer Number cannot be empty or blank spaces")
    private String customerNumber;
    @NotNull(message = "Customer Name is required")
    @NotBlank(message = "Customer Name cannot be empty or blank spaces")
    private String name;
    private String contactPhoneNumber;
    private String email;
    @OneToMany(mappedBy = "customer", cascade = CascadeType.ALL)
    private List<Account> accounts;

    public List<Account> getAccounts() {
        return accounts;
    }

    public void setAccounts(List<Account> accounts) {
        this.accounts = accounts;
    }

}
