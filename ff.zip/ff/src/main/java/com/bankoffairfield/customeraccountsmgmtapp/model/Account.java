package com.bankoffairfield.customeraccountsmgmtapp.model;

import lombok.*;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Table(name = "accounts")
public class Account {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long accountId;
    @Column(nullable = false, unique = true)
    @NotNull(message = "Account Type is required")
    @NotBlank(message = "Account Type cannot be empty or blank spaces")
    private  String accountNumber;
    @NotNull(message = "Account Type is required")
    @NotBlank(message = "Account Type cannot be empty or blank spaces")
    private String accountType;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateOpened;
    private Double balance;
    @ManyToOne(cascade = CascadeType.ALL)
    @JoinColumn(name="customer_id", nullable = false)
    private Customer customer;


}
